JARVIS APK — ESTRUTURA DE BUILD
================================
Este pacote é um projeto Android configurado para gerar um APK.

Para gerar:
1. Abra a pasta no Android Studio.
2. Aguarde o Gradle sincronizar.
3. Use Build > Build APK(s).
4. O APK ficará em app/build/outputs/apk/debug/.

O ambiente desta conversa não possui Android SDK/Gradle para compilar o APK binário aqui.
