package com.jarvis.mobile
import android.app.*
import android.content.Intent
import android.os.IBinder
class JarvisService: Service(){
 override fun onCreate(){ super.onCreate()
  val ch=NotificationChannel("jarvis","JARVIS",NotificationManager.IMPORTANCE_LOW)
  getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
  val n=Notification.Builder(this,"jarvis").setContentTitle("JARVIS ativo").setContentText("Assistente em segundo plano").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
  startForeground(7,n)
 }
 override fun onStartCommand(i:Intent?,f:Int,id:Int)=START_STICKY
 override fun onBind(i:Intent?):IBinder?=null
}
