package com.jarvis.mobile
import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.widget.*
import java.util.*

class MainActivity: android.app.Activity(), TextToSpeech.OnInitListener {
 private lateinit var tts: TextToSpeech
 private lateinit var answer: TextView
 override fun onCreate(b: Bundle?) { super.onCreate(b)
  if(android.os.Build.VERSION.SDK_INT>=23) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS),10)
  tts=TextToSpeech(this,this)
  val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(28,50,28,28)
  root.setBackgroundColor(android.graphics.Color.rgb(2,7,13))
  val title=TextView(this); title.text="🪶  JARVIS"; title.textSize=30f; title.setTextColor(android.graphics.Color.WHITE)
  val sub=TextView(this); sub.text="ONLINE • Assistente móvel"; sub.setTextColor(android.graphics.Color.CYAN)
  answer=TextView(this); answer.text="Pronto para ajudar."; answer.textSize=18f; answer.setTextColor(android.graphics.Color.WHITE); answer.setPadding(0,40,0,30)
  val input=EditText(this); input.hint="Digite um comando..."; input.setTextColor(android.graphics.Color.WHITE); input.setHintTextColor(android.graphics.Color.GRAY)
  val send=Button(this); send.text="Enviar"; send.setOnClickListener { respond(input.text.toString()) }
  val mic=Button(this); mic.text="🎙️ Ouvir"; mic.setOnClickListener { startActivityForResult(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE,"pt-BR"),20) }
  root.addView(title); root.addView(sub); root.addView(answer); root.addView(input); root.addView(send); root.addView(mic)
  setContentView(root)
  startService(Intent(this,JarvisService::class.java))
 }
 private fun respond(q:String){ if(q.isBlank()) return; val r="Entendi: $q"; answer.text=r; if(::tts.isInitialized) tts.speak(r,TextToSpeech.QUEUE_FLUSH,null,"jarvis") }
 override fun onActivityResult(rc:Int,res:Int,data:Intent?){ super.onActivityResult(rc,res,data); if(rc==20 && res==RESULT_OK){ val s=data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull(); if(s!=null) respond(s)}}
 override fun onInit(status:Int){ if(status==TextToSpeech.SUCCESS) tts.language=Locale("pt","BR") }
 override fun onDestroy(){ tts.shutdown(); super.onDestroy() }
}
